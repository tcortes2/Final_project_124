# Insert your TOGETHER_API_KEY and remove '.example' from the file name 
TOGETHER_API_KEY = "d572da9ba570e1cbc129130c03e631a01690b7b55cdb18f3bbc5e7ee4800bd8f"
